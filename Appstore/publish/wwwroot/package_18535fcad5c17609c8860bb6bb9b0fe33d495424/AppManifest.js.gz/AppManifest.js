var UnoAppManifest = {
    displayName: "Appstore",
    splashScreenImage: "splash_screen.scale-200.png",
    splashScreenColor: "#ffffff",
}